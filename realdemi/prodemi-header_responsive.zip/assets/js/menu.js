document.addEventListener('DOMContentLoaded', function () {
  const burgerButton = document.getElementById('burger-button'); // Botón de menú hamburguesa
  const mobileNav = document.querySelector('.mobile-nav'); // Menú móvil

  console.log(burgerButton, mobileNav)

  if (!burgerButton || !mobileNav) {
    console.error('Error: Elementos no encontrados en el DOM.');
    return;
  }

  // Evento para mostrar/ocultar el menú móvil
  burgerButton.addEventListener('click', function () {
    mobileNav.classList.toggle('active');
  });
});
